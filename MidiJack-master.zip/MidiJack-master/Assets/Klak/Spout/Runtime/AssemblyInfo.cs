// KlakSpout - Spout video frame sharing plugin for Unity
// https://github.com/keijiro/KlakSpout

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Klak.Spout.Editor")]
